This is a model of the Wavefrontier T90 LNB holder.

Print settings used:
* PLA
* 5% infill
* Supports are definitely needed

Additional items needed:
* 3 flat tip M4 screws

Note: PLA is a lot stiffer than the original material. You may want to use a more flexible material (such as TPU).

